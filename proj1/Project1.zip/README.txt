Name: Bradley Bauer
Time: ~1.5 hours
