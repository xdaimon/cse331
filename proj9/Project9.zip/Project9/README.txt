Project 9 pt 1

Name: Bradley Bauer

Time to Complete: 

Feedback: Graph.Vertex._eq_ doesn't always return a Bool

Sources Used: 
