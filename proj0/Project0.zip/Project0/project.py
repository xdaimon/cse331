def get_len(x : str):
    return len(x)
