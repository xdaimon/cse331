Project 6

Name: Bradley Bauer
Time to Complete: 4hr roughly
Feedback:

Sources Used: slides for definition and height/depth code, stackoverflow for 'yield from idea'
