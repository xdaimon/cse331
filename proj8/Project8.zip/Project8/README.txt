name: bradley bauer
time: 2 hr to get main functionality
    : 1 hr to find a way to do nlogn heapsort
feedback: it would have been nice to let the heap constructor take a comparison predicate (to implement a maxheap) and to let percolate_down take the table size so that students could figure out a way to do inplace heapsort even if it wasn't required. atleast that's the way i thought of doing it, maybe i missed something that could've let me get there without modifying the project.

sources: MIT OCW for build_heap and build_heap time analysis
